package com.crudoperation.simplelibrarysystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimplelibrarysystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimplelibrarysystemApplication.class, args);
	}

}
