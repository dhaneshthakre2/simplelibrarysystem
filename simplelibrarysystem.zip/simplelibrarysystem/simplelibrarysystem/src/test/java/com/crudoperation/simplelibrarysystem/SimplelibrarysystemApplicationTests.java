package com.crudoperation.simplelibrarysystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimplelibrarysystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
